﻿using System;

namespace HospitalLibrary
{
    public interface IPatient
    {
         string Name { get; set; }
        void Admit();
    }
    public class Patient 
    {
        public int Id { get; set; }
        public string name { get; set; }
        public string code { get; set; }
        public double BillAmount { get; set; }

    }
    public class EmerPatient : IPatient
    {
        public string Name { get; set; }

        public void Admit()
        {
            
        }
    }

}
