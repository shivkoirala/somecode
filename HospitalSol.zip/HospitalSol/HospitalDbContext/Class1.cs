﻿using HospitalLibrary;
using Microsoft.EntityFrameworkCore;
using System;

namespace HospitalDbContext
{
    public class PatientDbContext : DbContext
    {
        public PatientDbContext(DbContextOptions d) : base(d)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Patient>().ToTable("tblPatient");
        }
        public DbSet<Patient> Patients { get; set; }
    }
}
