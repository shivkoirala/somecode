﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using HospitalWebApplication.Models;
using HospitalLibrary;
using Microsoft.AspNetCore.Http;

namespace HospitalWebApplication.Controllers
{
    public class HomeController : Controller
    {
        private int Counter=0;
        private readonly ILogger<HomeController> _logger;
        //private IPatient patient = null;
        public HomeController(ILogger<HomeController> logger )
        {
           
            _logger = logger;
          //  patient = _p;
        }

        public IActionResult Index()
        {
            byte[] x = null;
            if (HttpContext.Session.TryGetValue("CounterCookie", out x))
            {
                Counter = (int) HttpContext.Session.GetInt32("CounterCookie");
            }
            Counter = Counter + 1;
            HttpContext.Session.SetInt32("CounterCookie", (int)Counter);
            ViewBag.vd123 = Counter;
            TempData["td123"] = DateTime.Now;
            return View("Start");
        }

        public IActionResult Privacy()
        {
            
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
