﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HospitalLibrary;
using Microsoft.AspNetCore.Mvc;

namespace HospitalWebApplication.Controllers
{
    public class PatientController : Controller
    {
        public IActionResult Add()
        {
            return View("PatientAdd"); // Screen
        }
        public IActionResult SavePatient(dynamic obj)
        {
            
            obj.name = obj.name.ToUpper();
            //{"Name" : "Shiv"}
            return Json(obj);
        }
        public IActionResult Update()
        {
            return View();
        }
    }
}
