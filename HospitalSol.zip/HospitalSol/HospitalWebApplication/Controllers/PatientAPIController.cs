﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HospitalLibrary;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using Microsoft.AspNetCore.Cors;
using HospitalDbContext;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HospitalWebApplication.Controllers
{
    [EnableCors("CorsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class PatientAPIController : ControllerBase
    {
        PatientDbContext db = null;
        public PatientAPIController(PatientDbContext _db)
        {
            db = _db;
        }
        // GET: api/<PatientAPIController>
        [HttpGet]
        public IActionResult Get()
        {
            List<Patient> pats = db.Patients.ToList<Patient>();
            return Ok(pats);
        }

        // GET api/<PatientAPIController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
           
            return "value";
        }

        // POST api/<PatientAPIController>
        [HttpPost]
        public IActionResult Post(Patient obj)
        {
            
            obj.name = obj.name.ToUpper();
            
            if (obj.name.Length == 0)
            {
                return  StatusCode((int) HttpStatusCode.InternalServerError, "Name is required");
            }
            else
            {
                db.Patients.Add(obj);
                db.SaveChanges();
                List<Patient> pats = db.Patients.ToList<Patient>();
                return Ok(pats);
            }
        }

        // PUT api/<PatientAPIController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<PatientAPIController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
