import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './HomeApp.MasterPageComponent.html'
})
export class MasterPageComponent {
  
}
