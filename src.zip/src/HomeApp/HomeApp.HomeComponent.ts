import { Component } from '@angular/core';

@Component({
  templateUrl: './HomeApp.HomeComponent.html'
})
export class HomeComponent {
  
}
