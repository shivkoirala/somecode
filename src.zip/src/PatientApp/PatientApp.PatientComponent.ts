import { Component } from '@angular/core';
import { Patient } from './PatientApp.PatientModel';
import {HttpClient} from "@angular/common/http"
@Component({
  templateUrl: './PatientApp.PatientComponent.html'
})
export class PatientComponent {
  title = 'HIMS';
  patObj:Patient = new Patient();
  patObjs:Array<Patient> = new Array<Patient>();
  value:string="";
  constructor(public http:HttpClient){
    var observable= this.http.get("https://localhost:44398/api/PatientAPI");
    observable.subscribe(res=>this.Success(res),
                res=>this.Error(res));
  }
  Add(){
    this.patObjs.push(this.patObj);
    this.patObj =new Patient();
  }
  Submit(){
    var patDTO:any = {};
    patDTO.name = this.patObj.name;
    patDTO.code = this.patObj.code;
    patDTO.billAmount = this.patObj.billAmount;
     var observable= this.http.post("https://localhost:44398/api/PatientAPI"
      ,patDTO);
      observable.subscribe(res=>this.Success(res),
                  res=>this.Error(res));
  }
  Success(res:any){
    this.patObjs=res;
    this.patObj= new Patient();
  }
  Error(res:any){
    console.log(res);
  }
}
