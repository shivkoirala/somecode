import {NgForm,
    FormGroup,
        FormControl,
            Validators,FormBuilder
        } from '@angular/forms'
export class Patient{
    name:string="";
    code:string="";// ABC1001 PQR9008
    billAmount:number=0;
    formPatientGroup:FormGroup = null;
    constructor(){
        var _builder = new FormBuilder();
        this.formPatientGroup = _builder.group({});
        this.formPatientGroup.addControl("pnameControl", 
        new FormControl('',Validators.required));
        
        var validationcollection = [];
        validationcollection.push(Validators.required);
        validationcollection.push(Validators.pattern("^[A-Z]{2,2}[0-9]{4,4}$"))
        this.formPatientGroup.addControl("pcodeControl", 
        new FormControl('',Validators.compose(validationcollection)));
    }
}